package com.mycompany.projetoa3;

import java.io.InputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;


public class client {

    ControleJogo controler = new ControleJogo();
    
    Socket socket;
    private int Port;
    private String concatStr;
    private String StringInicial;
    private String[] arrayString;
    private char [] voltaCharJogo;
    private String vaiStrJogo;
    private char[] charJogo;
    
    
    public void primeiraConexao(String nickClient, String marcadorClient, String ip, String porta) throws Exception{
        Port = Integer.parseInt(porta);
        socket = new Socket(ip, Port);
        Interface objInterface = new Interface();
        
        controler.setNickClient(nickClient);
    
        concatStr = "T;" + marcadorClient + ";" + nickClient;
        // Enviar mensagem para o servidor
        Conexao.enviar(socket, concatStr);
        
        
        // Receber mensagem do servidor
        while(true){
            StringInicial = Conexao.receber(socket);
            arrayString = StringInicial.split(";");
            if(arrayString[0].equals("T")){
                controler.setMarcadorServer(arrayString[1]);
                controler.setNickServer(arrayString[2]);

                //Libera o game para começar
                String strJogo= "0---------";
                setCharJogo(strJogo);

                System.out.println(getCharJogo());
                System.out.println("passou por aqui ");  
                
                
//                new Thread(esperaJogada).start();
                String vaiStrJogo = String.valueOf(charJogo);

//                vaiStrJogo = "1---C-----";
                // Enviar mensagem para o servidor
                Conexao.enviar(socket, vaiStrJogo);
                System.out.println("JogadaEnviada");


            }else{
                String voltaStrJogo;
                voltaStrJogo = Conexao.receber(socket);
                voltaCharJogo = voltaStrJogo.toCharArray();
    //            controler.setCharJogo(voltaCharJogo);

                System.out.println("Servidor enviou: " + voltaStrJogo);
            }
        }
        
    }
    
    
    public void jogada(char[] charJogo) throws Exception {    
        
        String vaiStrJogo = String.valueOf(charJogo);
        
        vaiStrJogo = "1---C-----";
        // Enviar mensagem para o servidor
        Conexao.enviar(socket, vaiStrJogo);
        System.out.println("JogadaEnviada");
    }

    public static void main(String[] args) {
        Interface objInterface = new Interface();
        objInterface.setVisible(true);
    }  
    
    private static Runnable esperaJogada = new Runnable(){
        public void run(){
            Interface objInterface = new Interface();
            do{

            }while(objInterface.aguardaJogada()==false);
            
        }
    };

   
    public void setCharJogo(String strJogo) {
        charJogo = strJogo.toCharArray();
    }
    public char[] getCharJogo() {
        return charJogo;
    }

    public String getVaiStrJogo() {
        return vaiStrJogo;
    }

    public void setVaiStrJogo(String vaiStrJogo) {
        this.vaiStrJogo = vaiStrJogo;
    }
    
}